# KANAK AI Studio — secure release and migration

**Source:** Google AI Studio project `ffab880f-4a04-4378-b5bf-365f0000a2f7` (this is NOT `com.kanak.app` from a separate GitHub project).

**Package:** `com.aistudio.kanak.fmcgbh`  
**Google/Firebase project:** `gen-lang-client-0792312038`  
**Named Firestore database:** `ai-studio-android-kanak-ffab880f-4a04-4378-b5bf-365f0000a2f7`

## Current verification level

The source has been modified locally and the JVM licensing / Bahrain financial tests, Apps Script mock identity tests, XML checks and source-level safety tests have passed. **The full Android APK has NOT been compiled from this modified source, Android devices have NOT run it, Firestore rules have NOT been deployed to Google, and a genuine two-account end-to-end activation has NOT passed.** Do not sell or distribute it until those are complete.

## Core security improvements

1. No fixed activation salt, deterministic customer-computable code, universal development bypass or accepted fake demo Firebase identity.
2. Firebase Authentication must complete and supply a verified email and correct UID. A cached email/role or Google token from another project is not authorization.
3. Registration is created online by the verified company owner. Its Firestore record stores `ownerUid` and starts `PENDING`; failed cloud registration no longer reports success.
4. The master administrator (verified Google account `zanabalmuhamed@gmail.com`) may issue a random 128-bit code after manually entering an independent payment reference. `INTERNAL-TEST` can be used for a test registration; this is not proof of payment.
5. The code is stored exclusively in administrator-readable `/license_codes/{requestId}`. The owner redeems the code, which updates `/company_registrations/{requestId}` to `ACTIVATED` **only** if Firestore rules compare the submitted code with the private document and it is unexpired. This makes the registered company the sole beneficiary and prevents a second PENDING -> ACTIVATED transition.
6. After one online activation, the app caches a device-bound HMAC receipt with an Android Keystore non-exportable key, tied to Google UID and company ID. This allows offline continued use on the same installation. A rooted device or tampered APK can still subvert local UI checks; this is not an unbreakable DRM guarantee. Online privileged writes remain protected by server security rules.
7. Firestore default deny; registration reads owner/admin only; license-code reads admin only; user and invoice cloud access scoped by verified UID; no public customer registration exposure.
8. TLS-only outbound Android traffic, no automatic app-data backup, no HTTP BODY logs of tokens/financial payloads.
9. Original uploaded signing keystore deliberately **excluded** from the revised ZIP. It should be backed up privately; evaluate rotation if its bytes have been shared publicly.
10. Publicly linked Drive image uploads into a shared owner folder disabled, pending separate tenant-owned private image storage.

## Deployment prerequisites — no paid infrastructure requested

Your existing Google Cloud project's billing stays unchanged. We have not enabled or linked billing. Google Firebase/Firestore/Apps Script have free usage quotas, but users must confirm actual quota and service eligibility. **Do not enable paid services or billing merely to make a build pass.**

Google OAuth consent must allow the test accounts during Testing. Go to [Google Auth Platform Audience](https://console.cloud.google.com/auth/audience?project=gen-lang-client-0792312038), and register `amwaj.bookkeeping@gmail.com` and the intended operator under Test users. Verify the Android OAuth client for `com.aistudio.kanak.fmcgbh` has the actual new APK signing SHA-1. An earlier `403 access_denied` screenshot specifically said the account wasn't an approved tester. Do not mix this with the separate GitHub application's `com.kanak.app` fingerprint or license code.

Before live rollout:

1. Review `firestore.rules`, compare against the current rules in the **named** Firestore database, export/back up the existing rules and registration records, and test rules in the Firebase Emulator Suite with authorized and unauthorized Firebase accounts. `firebase.json` deliberately targets the named Firestore DB above, **not** `(default)`. Deploy only after review and explicit authorization. Changes will deny formerly public reads/updates.
2. Run `gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug` in Android Studio with Android SDK/Gradle installed. The uploaded ZIP did **not** include a functional `gradlew` wrapper executable/JAR, so use an installed Gradle version compatible with the Android plugin. Resolve any compile errors before installing on a phone.
3. For an updateable customer release, set `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` in a **private** signing environment. Never add the original keystore to version control or a distributable ZIP. If this package was previously distributed, preserving its original signing identity is required for an in-place APK update; changing the key normally requires uninstall/reinstall and migration planning.
4. Build a signed APK: `gradle :app:assembleRelease`. Verify with `apksigner verify --verbose --print-certs app/build/outputs/apk/release/app-release.apk`. Check that package and SHA-1 match the existing Google OAuth Android client.
5. First test: sign in with a Google test user; register a fresh test company; verify ownerUid, PENDING state and owner-only registration read. Sign in separately as the verified administrator and enter `INTERNAL-TEST` in the payment-reference field; issue code in Master License Portal. Confirm code is **NOT** visible to another Google account. On the original phone, redeem it; verify Firestore status becomes ACTIVATED once. Test invalid, expired, other-company, replayed and revoked cases.
6. Switch device offline after confirmed activation, restart and verify permitted local operation. Sign out and sign in as a different Google UID: the first company's offline license must **not** unlock that user's session. Confirm invoice/customer operations never cross company boundaries.
7. Ensure Google Sheets gateway is deployed **per company**, bound to that company's own workbook and authorized `Users` sheet. This release does not provide an automatic multi-tenant workbook provisioning API. Set Apps Script Script Properties: `KANAK_FIREBASE_API_KEY` (the correct Firebase project's Web API key) and `KANAK_ADMIN_EMAIL` (Google account of the workbook owner). Apps Script validates Firebase ID tokens via `accounts:lookup` and matches exact UID **and** email against `Users`. Wrong/missing configuration fails closed. Do not reuse one shared workbook as a multi-company business database.
8. Obtain a privacy-policy URL, company support address, OAuth verification (if required for your selected scopes), error reporting and a reproducible release/signing process before commercial distribution. Do not claim Google OAuth Production approval or Play Store approval on the strength of source tests.

## Existing registration migration

**Old KNK-REQ-XXXX-XXXX requests and old `KNK-ACT-XXXX-XXXX` codes are NOT compatible** with the new secure flow. Older records lack a verified `ownerUid`; allowing those records to activate without a verified migration would reintroduce impersonation. Preserve old data and either re-register while logged in to the new APK or perform a reviewed server-side migration that proves the original Google account owns each record. Do not simply set ownerUid using email text supplied by the device.

New request IDs: `KNK-REQ-` followed by eight groups of four hexadecimal characters. New activation codes: `KNK-ACT-` followed by eight groups of four hexadecimal characters. The codes are generated by the administrator using secure randomness and expire in 14 days if not redeemed. **Company activation does not have an expiration** under the present design; the original code need not be retained by customers after validation.

## Explicit limitations and next development gates

- Backend data isolation beyond licensing: the existing Sheets gateway and local repository need a real tenant-aware end-to-end acceptance run. The source ZIP does not establish complete financial/data-security acceptance across every retail transaction workflow.
- Cloud image uploads intentionally fail closed until private per-company storage exists.
- Firestore Security Rules `get()`/`exists()` calls cause Firestore document reads and can consume quota; avoid any assumption that all production usage is free regardless of scale.
- AndroidKeyStore receipts bind offline use to the device/user installation and cannot survive uninstall or an Android Keystore reset; owner should revalidate online after reinstall.
- No new Firebase project was created, no paid service was provisioned, no live production rules or apps were modified as part of this ZIP revision.
