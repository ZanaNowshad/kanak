package com.example.kanak.licensing

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey

/**
 * A local tamper-resistant receipt written only after Firestore has confirmed
 * company activation. The signing key is non-exportable in AndroidKeyStore.
 * Not a substitute for an authoritative server check on compromised devices.
 */
internal object OfflineLicenseReceipt {
    private const val ALIAS = "kanak_license_receipt_v2"
    private const val SIGNATURE = "license_receipt_signature_v2"
    private const val RECEIPT = "license_receipt_payload_v2"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val current = store.getKey(ALIAS, null)
        if (current is SecretKey) return current
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
            .setDigests(KeyProperties.DIGEST_SHA256).build())
        return generator.generateKey()
    }

    private fun payload(uid: String, companyId: String): String =
        "KANAK|v2|$uid|$companyId|ACTIVE"

    private fun sign(data: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(key())
        return mac.doFinal(data.toByteArray(StandardCharsets.UTF_8))
    }

    fun save(prefs: SharedPreferences, uid: String, companyId: String) {
        val receipt = payload(uid, companyId)
        val signature = Base64.encodeToString(sign(receipt), Base64.NO_WRAP)
        check(prefs.edit().putString(RECEIPT, receipt).putString(SIGNATURE, signature)
            .remove("lic_is_activated").remove("lic_activation_code").commit()) {
            "Unable to persist offline license confirmation"
        }
    }

    fun isValid(prefs: SharedPreferences, uid: String, companyId: String): Boolean {
        val stored = prefs.getString(RECEIPT, null) ?: return false
        if (stored != payload(uid, companyId)) return false
        val candidate = prefs.getString(SIGNATURE, null) ?: return false
        return try {
            val signature = Base64.decode(candidate, Base64.NO_WRAP)
            java.security.MessageDigest.isEqual(sign(stored), signature)
        } catch (_: Exception) {
            false
        }
    }

    fun clear(prefs: SharedPreferences) {
        prefs.edit().remove(RECEIPT).remove(SIGNATURE)
            .remove("lic_is_activated").remove("lic_activation_code").apply()
    }
}
