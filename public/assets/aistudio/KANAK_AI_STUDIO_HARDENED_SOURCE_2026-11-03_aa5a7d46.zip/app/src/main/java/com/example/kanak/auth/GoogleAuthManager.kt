package com.example.kanak.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.example.R
import com.example.kanak.domain.models.User
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class Authenticated(val user: User, val idToken: String) : AuthState()
    data class Error(val message: String) : AuthState()
    data class AccessDenied(val reason: String = "Your account is not authorized to access Kanak.") : AuthState()
    object Unauthorized : AuthState()
}

/**
 * Google Authentication Manager using modern Android Credential Manager with Google Sign-In and Firebase Auth.
 * Supports Google account sign-in, token retrieval, session restoration, and demo sign-in for zero-setup local operation.
 */
class GoogleAuthManager(private val context: Context) {

    private val credentialManager = CredentialManager.create(context)
    
    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    init {
        restoreSession()
    }

    private fun restoreSession() {
        // Firebase persists verified identity using its own secure auth SDK.
        // Never restore a user, role, or ID token from editable SharedPreferences.
        val firebaseUser = FirebaseAuth.getInstance().currentUser ?: return
        if (!firebaseUser.isEmailVerified) return
        val user = User(
            userId = firebaseUser.uid,
            email = firebaseUser.email.orEmpty(),
            role = User.ROLE_ADMIN,
            active = true
        )
        _authState.value = AuthState.Authenticated(user, "firebase-session-managed")
    }

    /**
     * Signs in using Android Credential Manager with Google Sign-In Option and links with Firebase Auth.
     */
    suspend fun signInWithGoogle(serverClientId: String? = null): AuthState = withContext(Dispatchers.IO) {
        _authState.value = AuthState.Loading

        val clientId = serverClientId ?: try {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) context.getString(resId) else ""
        } catch (e: Exception) {
            ""
        }

        val signInWithGoogleOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInWithGoogleOption)
            .build()

        try {
            val result: GetCredentialResponse = credentialManager.getCredential(
                request = request,
                context = context
            )
            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                // Fail closed: an unverified or failed Firebase sign-in does NOT
                // establish an application session or an administrator identity.
                val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                val signedIn = FirebaseAuth.getInstance().signInWithCredential(firebaseCredential).await().user
                    ?: error("Firebase did not establish a verified session")
                require(signedIn.isEmailVerified) { "Google account email is unverified" }
                val user = User(
                    userId = signedIn.uid,
                    email = signedIn.email.orEmpty(),
                    role = User.ROLE_ADMIN, // Company role only; not the master license administrator.
                    active = true
                )
                val state = AuthState.Authenticated(user, "firebase-session-managed")
                _authState.value = state
                return@withContext state
            } else {
                val err = AuthState.Error("Unsupported credential type returned")
                _authState.value = err
                return@withContext err
            }
        } catch (e: GetCredentialCancellationException) {
            android.util.Log.w("GoogleAuthManager", "Google Sign-In was cancelled: ${e.message}")
            val state = AuthState.Idle
            _authState.value = state
            return@withContext state
        } catch (e: GetCredentialException) {
            val errState = AuthState.Error("Google Sign-In failed: ${e.message ?: "Authentication error"}")
            _authState.value = errState
            return@withContext errState
        } catch (e: Exception) {
            val errState = AuthState.Error("Sign-In failed: ${e.message ?: "Connection error"}")
            _authState.value = errState
            return@withContext errState
        }
    }

    /**
     * Provides a fast, secure role-switchable demo account for testing van sales operations.
     */
    /** Demo identities are not accepted by the live multi-tenant application. */
    fun signInAsDemo(asAdmin: Boolean = true): AuthState {
        val state = AuthState.Error("Demo login is disabled. Use your verified Google account.")
        _authState.value = state
        return state
    }

    fun signOut() {
        FirebaseAuth.getInstance().signOut()
        _authState.value = AuthState.Idle
    }
}
