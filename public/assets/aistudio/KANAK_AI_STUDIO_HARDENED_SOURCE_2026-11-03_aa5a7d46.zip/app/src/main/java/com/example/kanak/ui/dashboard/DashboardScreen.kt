package com.example.kanak.ui.dashboard

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.kanak.data.repository.KanakRepository
import com.example.kanak.domain.financial.BahrainFinancials
import com.example.kanak.domain.models.User
import com.example.kanak.ui.components.DashboardMetricCard
import com.example.kanak.ui.components.EmptyStateView
import com.example.kanak.ui.components.TopSellingProductRow
import com.example.ui.theme.*
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    repository: KanakRepository,
    currentUser: User,
    isMasterAdmin: Boolean = false,
    onNavigateToNewInvoice: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAdminLicensePortal: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val summary by repository.dashboardSummary.collectAsState()
    val products by repository.products.collectAsState()

    val todayDateFormatted = remember {
        val df = SimpleDateFormat("EEE, d MMM yyyy", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("Asia/Bahrain")
        }
        df.format(Date())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "KANAK",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = KanakPrimaryText,
                                fontSize = 20.sp
                            )
                        )
                        Text(
                            text = "by zedosai.com",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = KanakSecondaryText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                },
                actions = {
                    // Prominent Master Admin Button for zanabalmuhamed@gmail.com
                    if (isMasterAdmin) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEF3C7),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onNavigateToAdminLicensePortal?.invoke() }
                                .testTag("topbar_admin_portal_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = "Admin Portal",
                                    tint = Color(0xFFD97706),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "ADMIN",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF92400E),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Notification bell with indicator
                    Box(modifier = Modifier.padding(end = 4.dp)) {
                        IconButton(onClick = {}) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = KanakPrimaryText
                            )
                        }
                        Surface(
                            shape = CircleShape,
                            color = KanakError,
                            modifier = Modifier
                                .size(8.dp)
                                .align(Alignment.TopEnd)
                                .offset(x = (-8).dp, y = 10.dp)
                        ) {}
                    }

                    // User Avatar Initials Pill
                    Surface(
                        shape = CircleShape,
                        color = if (isMasterAdmin) Color(0xFFFEF3C7) else KanakSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isMasterAdmin) Color(0xFFF59E0B) else KanakDivider),
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onNavigateToSettings)
                            .testTag("dashboard_settings_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = currentUser.initials,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMasterAdmin) Color(0xFF92400E) else KanakPrimaryText
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = KanakBackground,
                    titleContentColor = KanakPrimaryText
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToNewInvoice,
                shape = CircleShape,
                containerColor = KanakPrimaryBlue,
                contentColor = Color.White,
                elevation = FloatingActionButtonDefaults.elevation(4.dp),
                modifier = Modifier.testTag("dashboard_new_invoice_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Invoice", modifier = Modifier.size(28.dp))
            }
        },
        containerColor = KanakBackground,
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(KanakBackground)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Master Admin Control Banner (Prominent for zanabalmuhamed@gmail.com)
            if (isMasterAdmin) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onNavigateToAdminLicensePortal?.invoke() }
                            .testTag("dashboard_master_admin_banner"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFD97706),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AdminPanelSettings,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "MASTER ADMIN CONTROL CENTER",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF92400E),
                                        fontSize = 12.sp,
                                        letterSpacing = 0.5.sp
                                    )
                                )
                                Text(
                                    text = "Review incoming company registrations & issue paid activation codes",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color(0xFF78350F),
                                        fontSize = 11.sp
                                    )
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFD97706),
                                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                            ) {
                                Text(
                                    text = "Open Portal",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Greeting & Date Section
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.WbSunny,
                                contentDescription = null,
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Good morning,",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = KanakSecondaryText,
                                    fontSize = 13.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        val greetingName = if (isMasterAdmin) "Zanabal" else currentUser.displayName.substringBefore(" ").ifBlank { "Partner" }
                        Text(
                            text = greetingName,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = KanakPrimaryText,
                                fontSize = 24.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isMasterAdmin) "Owner & Master Administrator" else "Let's make today count",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isMasterAdmin) Color(0xFFD97706) else KanakSecondaryText,
                                fontSize = 12.sp,
                                fontWeight = if (isMasterAdmin) FontWeight.SemiBold else FontWeight.Normal
                            )
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = KanakSurfaceVariant
                    ) {
                        Text(
                            text = todayDateFormatted,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = KanakSecondaryText,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Stat Cards Row with initial cold-launch mount roll (Plan 005)
            item {
                val isReducedMotion = LocalReducedMotion.current
                var hasMounted by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) {
                    hasMounted = true
                }

                val density = LocalDensity.current
                val targetOffsetPx = with(density) { 8.dp.toPx() }

                val kpiAlpha by animateFloatAsState(
                    targetValue = if (isReducedMotion || hasMounted) 1.0f else 0.0f,
                    animationSpec = tween(
                        durationMillis = if (isReducedMotion) 0 else MotionDuration.KpiMount,
                        easing = MotionCurves.EaseOut
                    ),
                    label = "kpi_mount_alpha"
                )

                val kpiOffsetY by animateFloatAsState(
                    targetValue = if (isReducedMotion || hasMounted) 0.0f else targetOffsetPx,
                    animationSpec = tween(
                        durationMillis = if (isReducedMotion) 0 else MotionDuration.KpiMount,
                        easing = MotionCurves.EaseOut
                    ),
                    label = "kpi_mount_offset_y"
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            alpha = kpiAlpha
                            translationY = kpiOffsetY
                        },
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    DashboardMetricCard(
                        title = "Today's Sales",
                        value = BahrainFinancials.formatBhd(summary.todaySalesTotal),
                        trendText = "+12% vs. yesterday",
                        icon = Icons.Default.PointOfSale,
                        iconColor = KanakSuccess,
                        iconBgColor = KanakSuccessBackground,
                        modifier = Modifier.weight(1f)
                    )

                    DashboardMetricCard(
                        title = "Invoices Today",
                        value = summary.todayInvoiceCount.toString(),
                        trendText = "+9% vs. yesterday",
                        icon = Icons.Default.Receipt,
                        iconColor = KanakPrimaryBlue,
                        iconBgColor = KanakAccentLight,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Top-Selling Products Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Top Selling Products",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = KanakPrimaryText,
                            fontSize = 17.sp
                        )
                    )
                    Text(
                        text = "See All",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = KanakPrimaryBlue
                        )
                    )
                }
            }

            // Top Selling Products Items
            if (summary.topSellingProducts.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.Receipt,
                        title = "No sales recorded yet today",
                        message = "Start your wholesale van delivery run by posting your first customer sales invoice."
                    )
                }
            } else {
                itemsIndexed(summary.topSellingProducts) { index, item ->
                    val prod = products.find { it.productId == item.productId }
                    TopSellingProductRow(
                        rank = index + 1,
                        name = item.productName,
                        qtySold = item.qtySold,
                        price = prod?.sellingPrice ?: BigDecimal.ZERO,
                        photoUrl = prod?.photoUrl
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}
