package com.example.ui.theme

import android.content.Context
import android.provider.Settings
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext

/**
 * Emil Kowalski Motion System for Kanak.
 * Authoritative easing curves, durations, springs, and tactile feedback.
 */
object MotionCurves {
    // --ease-out: cubic-bezier(0.23, 1, 0.32, 1)
    val EaseOut = CubicBezierEasing(0.23f, 1.0f, 0.32f, 1.0f)

    // --ease-in-out: cubic-bezier(0.77, 0, 0.175, 1)
    val EaseInOut = CubicBezierEasing(0.77f, 0.0f, 0.175f, 1.0f)

    // --ease-drawer: cubic-bezier(0.32, 0.72, 0, 1)
    val EaseDrawer = CubicBezierEasing(0.32f, 0.72f, 0.0f, 1.0f)
}

object MotionDuration {
    const val ButtonPress = 160
    const val Tooltip = 150
    const val Dropdown = 200
    const val Modal = 220
    const val Drawer = 350
    const val TabSwitch = 180
    const val KpiMount = 280
}

object MotionSprings {
    val Gentle = spring<Float>(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)
    val Pop = spring<Float>(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium)
}

/**
 * Composition local providing system-wide reduced motion state.
 */
val LocalReducedMotion = staticCompositionLocalOf { false }

@Composable
fun rememberIsReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember {
        try {
            val scale = Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1.0f
            )
            scale == 0.0f
        } catch (_: Exception) {
            false
        }
    }
}

/**
 * Subtle button press scale feedback (scale 0.96f over 100ms press / 160ms release).
 * Bypassed when reduced motion is enabled.
 */
fun Modifier.tactilePress(
    interactionSource: MutableInteractionSource,
    pressedScale: Float = 0.96f
): Modifier = composed {
    val isReducedMotion = LocalReducedMotion.current
    if (isReducedMotion) {
        return@composed this
    }

    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressedScale else 1.0f,
        animationSpec = tween(
            durationMillis = if (isPressed) 100 else MotionDuration.ButtonPress,
            easing = MotionCurves.EaseOut
        ),
        label = "tactile_press_scale"
    )

    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
