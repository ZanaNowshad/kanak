package com.example.kanak.licensing

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.kanak.data.firebase.KanakFirebaseManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class LicenseState { UNREGISTERED, PENDING_ACTIVATION, ACTIVATED }

data class CompanyProfile(
    val requestId: String = "",
    val companyName: String = "",
    val ownerName: String = "",
    val phone: String = "",
    val email: String = "",
    val crNumber: String = "",
    val address: String = "",
    val registrationDate: String = "",
    val isActivated: Boolean = false,
    val activationCode: String = "",
    val status: String = "PENDING"
)

/**
 * Google/Firebase-backed company licensing. The APK never computes a valid license.
 * Issued codes are held in Firestore's admin-only license_codes collection; Firestore
 * security rules compare the supplied proof before allowing a PENDING -> ACTIVATED
 * transition. A hardware-keystore HMAC permits offline use after one online validation.
 *
 * Important: offline access is resistance to casual preference editing, not a DRM
 * guarantee against a rooted device or a modified APK.
 */
class LicenseManager(private val context: Context) {
    companion object {
        const val MASTER_ADMIN_EMAIL = "zanabalmuhamed@gmail.com"
        const val MASTER_ADMIN_WHATSAPP = "+97333050666"
        const val MASTER_ADMIN_WHATSAPP_DIGITS = "97333050666"
        const val BRAND_NAME = "'Kanak' by zedosai.com"
        private const val PREFS_NAME = "kanak_licensing_prefs"
        private const val KEY_REQUEST_ID = "lic_request_id"
        private const val KEY_COMPANY_NAME = "lic_company_name"
        private const val KEY_OWNER_NAME = "lic_owner_name"
        private const val KEY_PHONE = "lic_phone"
        private const val KEY_EMAIL = "lic_email"
        private const val KEY_CR_NUMBER = "lic_cr_number"
        private const val KEY_ADDRESS = "lic_address"
        private const val KEY_REG_DATE = "lic_reg_date"
        private const val KEY_IS_ACTIVATED = "lic_is_activated"
        private const val KEY_ACTIVATION_CODE = "lic_activation_code"
        private const val KEY_OWNER_UID = "lic_owner_uid"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val firebaseManager = KanakFirebaseManager(context)
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val collection get() = firebaseManager.firestore.collection("company_registrations")
    private val codes get() = firebaseManager.firestore.collection("license_codes")

    private fun activeReceipt(): Boolean {
        val uid = auth.currentUser?.uid ?: return false
        val id = prefs.getString(KEY_REQUEST_ID, "") ?: ""
        if (prefs.getString(KEY_OWNER_UID, "") != uid || id.isBlank()) return false
        return OfflineLicenseReceipt.isValid(prefs, uid, id)
    }

    private fun loadInitialState(): LicenseState = when {
        activeReceipt() -> LicenseState.ACTIVATED
        prefs.getString(KEY_COMPANY_NAME, "").isNullOrBlank() -> LicenseState.UNREGISTERED
        else -> LicenseState.PENDING_ACTIVATION
    }

    private val _licenseState = MutableStateFlow(loadInitialState())
    val licenseState: StateFlow<LicenseState> = _licenseState.asStateFlow()
    private val _companyProfile = MutableStateFlow(loadProfile())
    val companyProfile: StateFlow<CompanyProfile> = _companyProfile.asStateFlow()

    /** A newly authenticated account must never inherit a different user's company. */
    fun refreshForAuthenticatedUser() {
        val uid = auth.currentUser?.uid
        val owner = prefs.getString(KEY_OWNER_UID, null)
        if (owner != null && owner != uid) prefs.edit().clear().apply()
        _companyProfile.value = loadProfile()
        _licenseState.value = loadInitialState()
    }

    fun loadProfile(): CompanyProfile {
        val active = activeReceipt()
        return CompanyProfile(
            requestId = prefs.getString(KEY_REQUEST_ID, "").orEmpty(),
            companyName = prefs.getString(KEY_COMPANY_NAME, "").orEmpty(),
            ownerName = prefs.getString(KEY_OWNER_NAME, "").orEmpty(),
            phone = prefs.getString(KEY_PHONE, "").orEmpty(),
            email = prefs.getString(KEY_EMAIL, "").orEmpty(),
            crNumber = prefs.getString(KEY_CR_NUMBER, "").orEmpty(),
            address = prefs.getString(KEY_ADDRESS, "").orEmpty(),
            registrationDate = prefs.getString(KEY_REG_DATE, "").orEmpty(),
            isActivated = active,
            // Never persist/re-display activation codes in application preferences.
            activationCode = "",
            status = if (active) "ACTIVATED" else "PENDING"
        )
    }

    /** UI convenience only; the Firestore master identity check is authoritative. */
    fun isMasterAdmin(email: String?): Boolean {
        val firebaseUser = auth.currentUser ?: return false
        return firebaseUser.isEmailVerified &&
            firebaseUser.email.equals(MASTER_ADMIN_EMAIL, ignoreCase = true) &&
            email.equals(firebaseUser.email, ignoreCase = true)
    }

    fun generateRequestId(): String {
        val raw = UUID.randomUUID().toString().replace("-", "").uppercase(Locale.US)
        return "KNK-REQ-${raw.chunked(4).joinToString("-")}"
    }

    suspend fun registerCompany(
        companyName: String, ownerName: String, phone: String,
        email: String, crNumber: String, address: String
    ): Result<CompanyProfile> = withContext(Dispatchers.IO) {
        runCatching {
            val user = auth.currentUser ?: error("Sign in with Google before registering a company")
            require(user.isEmailVerified) { "A verified Google account is required" }
            require(email.trim().equals(user.email, ignoreCase = true)) { "Account email mismatch" }
            require(companyName.trim().length in 2..120) { "Invalid company name" }
            require(ownerName.trim().length in 2..120) { "Invalid owner name" }
            require(phone.trim().length in 6..30) { "Invalid phone number" }
            require(address.trim().length in 2..250) { "Invalid address" }
            require(crNumber.trim().length <= 50) { "CR number too long" }
            val requestId = generateRequestId()
            val registered = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
            val profile = CompanyProfile(requestId, companyName.trim(), ownerName.trim(),
                phone.trim(), user.email.orEmpty(), crNumber.trim(), address.trim(), registered)
            // Cloud write is authoritative. A failed registration must not claim success.
            collection.document(requestId).set(mapOf(
                "requestId" to requestId,
                "ownerUid" to user.uid,
                "email" to profile.email,
                "companyName" to profile.companyName,
                "ownerName" to profile.ownerName,
                "phone" to profile.phone,
                "crNumber" to profile.crNumber,
                "address" to profile.address,
                "registrationDate" to profile.registrationDate,
                "targetAdminEmail" to MASTER_ADMIN_EMAIL,
                "status" to "PENDING", "isActivated" to false,
                "createdAt" to FieldValue.serverTimestamp()
            )).await()
            prefs.edit()
                .putString(KEY_REQUEST_ID, requestId)
                .putString(KEY_COMPANY_NAME, profile.companyName)
                .putString(KEY_OWNER_NAME, profile.ownerName)
                .putString(KEY_PHONE, profile.phone)
                .putString(KEY_EMAIL, profile.email)
                .putString(KEY_CR_NUMBER, profile.crNumber)
                .putString(KEY_ADDRESS, profile.address)
                .putString(KEY_REG_DATE, registered)
                .putString(KEY_OWNER_UID, user.uid)
                .remove(KEY_IS_ACTIVATED).remove(KEY_ACTIVATION_CODE)
                .apply()
            OfflineLicenseReceipt.clear(prefs)
            _companyProfile.value = profile
            _licenseState.value = LicenseState.PENDING_ACTIVATION
            profile
        }
    }

    suspend fun activateLicense(enteredCode: String): Result<Boolean> = validateAndActivate(enteredCode)

    suspend fun validateAndActivate(enteredCode: String): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val user = auth.currentUser ?: error("Sign in with your registered Google account")
            val profile = loadProfile()
            require(profile.requestId.isNotBlank()) { "Register your company first" }
            require(prefs.getString(KEY_OWNER_UID, "") == user.uid) { "Account does not own this company" }
            val code = LicenseCode.normalize(enteredCode)
            require(LicenseCode.isValid(code)) {
                "Code format is invalid. Paste the full code supplied by KANAK."
            }
            // Only Firestore's private license_codes rule can approve this update.
            collection.document(profile.requestId).update(mapOf(
                "status" to "ACTIVATED", "isActivated" to true,
                "activationProof" to code,
                "activatedAt" to FieldValue.serverTimestamp()
            )).await()
            OfflineLicenseReceipt.save(prefs, user.uid, profile.requestId)
            _companyProfile.value = loadProfile()
            _licenseState.value = LicenseState.ACTIVATED
            true
        }
    }

    suspend fun checkCloudActivationStatus(): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val user = auth.currentUser ?: error("Sign in before checking activation")
            val id = prefs.getString(KEY_REQUEST_ID, "").orEmpty()
            require(id.isNotBlank() && prefs.getString(KEY_OWNER_UID, "") == user.uid) {
                "Registration belongs to a different account or is missing"
            }
            // SERVER source prevents accidental trust in a locally cached Firestore document.
            val doc = collection.document(id).get(Source.SERVER).await()
            require(doc.exists() && doc.getString("ownerUid") == user.uid) {
                "Company was not found for this Google account"
            }
            val active = doc.getBoolean("isActivated") == true && doc.getString("status") == "ACTIVATED"
            if (active) {
                OfflineLicenseReceipt.save(prefs, user.uid, id)
            } else {
                OfflineLicenseReceipt.clear(prefs)
            }
            _companyProfile.value = loadProfile()
            _licenseState.value = loadInitialState()
            active
        }
    }

    fun createEmailIntent(profile: CompanyProfile): Intent {
        val subject = "[$BRAND_NAME] Registration request: ${profile.companyName}"
        val body = """KANAK company activation request
Company: ${profile.companyName}
Owner: ${profile.ownerName}
Phone: ${profile.phone}
Registered Google account: ${profile.email}
CR / TRN: ${profile.crNumber}
Address: ${profile.address}
Request ID: ${profile.requestId}
Please issue my one-time activation code after verifying payment."""
        return Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$MASTER_ADMIN_EMAIL")).apply {
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    fun createWhatsAppIntent(profile: CompanyProfile): Intent {
        val message = """KANAK registration request
Company: ${profile.companyName}
Owner: ${profile.ownerName}
Phone: ${profile.phone}
Email: ${profile.email}
CR: ${profile.crNumber}
Request ID: ${profile.requestId}"""
        return Intent(Intent.ACTION_VIEW,
            Uri.parse("https://api.whatsapp.com/send?phone=$MASTER_ADMIN_WHATSAPP_DIGITS&text=${Uri.encode(message)}")
        ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
    }

    suspend fun fetchAllRegistrations(): Result<List<CompanyProfile>> = withContext(Dispatchers.IO) {
        runCatching {
            require(isMasterAdmin(auth.currentUser?.email)) { "Verified administrator access required" }
            firebaseManager.firestore.collection("company_registrations").get(Source.SERVER).await()
                .documents.mapNotNull { doc ->
                    val name = doc.getString("companyName") ?: return@mapNotNull null
                    CompanyProfile(
                        requestId = doc.getString("requestId") ?: doc.id,
                        companyName = name, ownerName = doc.getString("ownerName").orEmpty(),
                        phone = doc.getString("phone").orEmpty(),
                        email = doc.getString("email").orEmpty(),
                        crNumber = doc.getString("crNumber").orEmpty(),
                        address = doc.getString("address").orEmpty(),
                        registrationDate = doc.getString("registrationDate").orEmpty(),
                        isActivated = doc.getBoolean("isActivated") == true,
                        status = doc.getString("status") ?: "PENDING"
                    )
                }
        }
    }

    /** Issues, but does NOT redeem, a fresh 128-bit random code. */
    suspend fun issueCodeForCompany(requestId: String, paymentReference: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(isMasterAdmin(auth.currentUser?.email)) { "Verified administrator required" }
            require(paymentReference.trim().length in 3..120) { "Verified payment reference or INTERNAL-TEST required" }
            val company = collection.document(requestId).get(Source.SERVER).await()
            require(company.exists() && company.getString("status") == "PENDING") { "Company is not pending" }
            require(company.getString("requestId") == requestId && company.getString("ownerUid")?.isNotBlank() == true) {
                "This legacy registration must be migrated/re-registered before secure activation"
            }
            val code = LicenseCode.generate()
            codes.document(requestId).set(mapOf(
                "requestId" to requestId,
                "code" to code,
                "issuedByUid" to auth.currentUser!!.uid,
                "issuedAt" to FieldValue.serverTimestamp(),
                "expiresAt" to Date(System.currentTimeMillis() + 14L * 24L * 60L * 60L * 1000L),
                "paymentReference" to paymentReference.trim()
            )).await()
            code
        }
    }

    /** Only the authenticated master admin can retrieve an unredeemed issued code. */
    suspend fun getIssuedCode(requestId: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(isMasterAdmin(auth.currentUser?.email)) { "Verified administrator required" }
            val doc = codes.document(requestId).get(Source.SERVER).await()
            require(doc.exists()) { "No code was issued for this company" }
            doc.getString("code") ?: error("Issued code missing")
        }
    }

    // Retained as an explicit error to prevent old UI/API callers silently activating
    // companies or computing licenses inside an untrusted customer APK.
    @Deprecated("Use issueCodeForCompany(requestId, verifiedPaymentReference)")
    suspend fun adminActivateCompany(requestId: String, companyName: String): Result<String> =
        Result.failure(IllegalStateException("Enter a verified payment reference and issue a code instead"))
}
