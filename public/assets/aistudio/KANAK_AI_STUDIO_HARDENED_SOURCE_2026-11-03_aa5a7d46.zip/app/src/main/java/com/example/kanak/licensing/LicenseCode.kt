package com.example.kanak.licensing

import java.security.SecureRandom
import java.util.Locale

/** Format/entropy checks for codes. The code itself is kept only in Firestore. */
object LicenseCode {
    private val codePattern = Regex("^KNK-ACT-([0-9A-F]{4}-){7}[0-9A-F]{4}$")
    private val random = SecureRandom()

    fun generate(): String {
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        val hex = bytes.joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        return "KNK-ACT-${hex.chunked(4).joinToString("-")}"
    }

    fun normalize(value: String): String = value.trim().uppercase(Locale.US)

    fun isValid(value: String): Boolean = codePattern.matches(value)
}
