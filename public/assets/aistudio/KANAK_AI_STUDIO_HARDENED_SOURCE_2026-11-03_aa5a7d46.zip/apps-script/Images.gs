/**
 * SECURITY: The old implementation placed every company's images in one
 * operator-owned Drive folder and granted ANYONE_WITH_LINK access.
 * That would disclose customer images and break tenant isolation. Disable the
 * operation until a customer-owned, per-company Drive authorization flow has
 * been designed, deployed and acceptance-tested.
 *
 * Existing manually provided product image URLs can still be used locally.
 */
function handleImageUpload(payload, user) {
  throw new Error('Cloud image upload is disabled pending private per-company storage setup. Use a manually approved photo URL.');
}
