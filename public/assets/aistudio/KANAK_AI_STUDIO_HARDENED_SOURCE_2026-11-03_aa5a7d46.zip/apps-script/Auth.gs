/**
 * KANAK authenticated Google Sheets gateway.
 * The Android client sends a short-lived Firebase ID token (not a self-asserted
 * user ID). The Firebase Authentication backend validates it via accounts:lookup.
 * Setup: set KANAK_FIREBASE_API_KEY and KANAK_ADMIN_EMAIL as Script Properties.
 * Account must already exist in this workbook's Users sheet, except for the
 * verified script owner whose administrator role is explicitly bootstrapped.
 */
function authenticateAndAuthorize(ss, idToken, requiredRole) {
  if (typeof idToken !== 'string' || !idToken || idToken.length > 8192) {
    throw new Error('A valid Firebase authentication token is required');
  }
  var props = PropertiesService.getScriptProperties();
  var firebaseKey = props.getProperty('KANAK_FIREBASE_API_KEY');
  if (!firebaseKey) throw new Error('KANAK_FIREBASE_API_KEY has not been configured');
  var response = UrlFetchApp.fetch(
    'https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + encodeURIComponent(firebaseKey),
    {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify({idToken: idToken}),
      muteHttpExceptions: true
    }
  );
  if (response.getResponseCode() !== 200) {
    throw new Error('Invalid or expired Firebase identity token');
  }
  var users = JSON.parse(response.getContentText()).users || [];
  if (users.length !== 1) throw new Error('Account identity not found');
  var identity = users[0];
  if (!identity.localId || !identity.email || identity.emailVerified !== true || identity.disabled === true) {
    throw new Error('A verified active Google account is required');
  }
  // Restrict the gateway to Google-linked accounts, not anonymous/password-only.
  var googleProvider = (identity.providerUserInfo || []).some(function(provider) {
    return provider.providerId === 'google.com';
  });
  if (!googleProvider) throw new Error('Google Sign-In is required');
  var uid = String(identity.localId);
  var email = String(identity.email).trim().toLowerCase();
  var sheet = ss.getSheetByName('Users');
  if (!sheet) throw new Error('Missing Users worksheet');
  var rows = sheet.getDataRange().getValues();
  var account = null;
  for (var row = 1; row < rows.length; row++) {
    var record = rows[row];
    if (String(record[0]) === uid && String(record[1]).trim().toLowerCase() === email) {
      var active = record[3] === true || String(record[3]).trim().toLowerCase() === 'true';
      if (!active) throw new Error('User is disabled');
      account = {userId: uid, email: email, role: String(record[2]).trim().toLowerCase(), active: true};
      break;
    }
  }
  // Bootstrap only the verified operator email, never a user-supplied address.
  var configuredAdmin = String(props.getProperty('KANAK_ADMIN_EMAIL') || '').trim().toLowerCase();
  if (!account && configuredAdmin && email === configuredAdmin &&
      email === String(Session.getEffectiveUser().getEmail() || '').trim().toLowerCase()) {
    account = {userId: uid, email: email, role: 'admin', active: true};
  }
  if (!account) throw new Error('This Google account is not registered in the workbook');
  if (account.role !== 'admin' && account.role !== 'standard') {
    throw new Error('Invalid user role');
  }
  if (requiredRole === 'admin' && account.role !== 'admin') {
    throw new Error('Administrator role required');
  }
  return account;
}
