from pathlib import Path
import json,re,xml.etree.ElementTree as ET,subprocess
root=Path(__file__).resolve().parents[1]
license_src=(root/'app/src/main/java/com/example/kanak/licensing/LicenseManager.kt').read_text()
auth=(root/'app/src/main/java/com/example/kanak/auth/GoogleAuthManager.kt').read_text()
rules=(root/'firestore.rules').read_text()
gateway=(root/'apps-script/Auth.gs').read_text()
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
app=manifest.find('application')
assert app.attrib[android+'usesCleartextTraffic']=='false'
assert app.attrib[android+'allowBackup']=='false'
assert not (root/'my-upload-key.jks').exists()
assert 'MASTER_SALT' not in license_src
assert 'KNK-MASTER-DEV-PASS' not in license_src
assert 'computeActivationCode' not in license_src
assert 'activeReceipt()' in license_src
assert 'Source.SERVER' in license_src
assert 'FirebaseAuth.getInstance().currentUser' in auth
assert 'demo_token_' not in auth
assert 'id.hashCode()' not in auth
assert 'Boolean(row[3])' not in gateway
assert 'tokeninfo?id_token=' not in gateway
assert 'accounts:lookup?' in gateway
assert 'request.auth != null' in rules
assert 'allow read: if true' not in rules
assert 'allow update: if isAuthenticated()' not in rules
assert 'get(/databases/$(database)/documents/license_codes/$(id))' in rules
assert 'request.resource.data.diff(resource.data).affectedKeys().hasOnly' not in rules or 'd.diff(resource.data).affectedKeys().hasOnly' in rules
assert 'code.expiresAt > request.time' in rules
assert 'request.resource.data.issuedAt == request.time' in rules
assert 'allow delete: if false' in rules
j=json.loads((root/'firebase.json').read_text())
assert j['firestore'][0]['database']=='ai-studio-android-kanak-ffab880f-4a04-4378-b5bf-365f0000a2f7'
for path in (root/'apps-script').glob('*.gs'):
  x=subprocess.run(['node','--check'],input=path.read_text(),text=True,capture_output=True)
  if x.returncode: # node --check reads STDIN by default
   raise AssertionError(f'Bad Apps Script syntax: {path.name} {x.stderr}')
print('PASS Android privacy flags, stripped signing key, no embedded license authority, Firestore owner/server checks, Firebase token verification, named DB, Apps Script syntax')
