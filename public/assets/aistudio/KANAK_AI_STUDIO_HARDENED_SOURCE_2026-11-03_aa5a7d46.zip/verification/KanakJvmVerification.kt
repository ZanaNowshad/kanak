import com.example.kanak.licensing.LicenseCode
import com.example.kanak.domain.financial.BahrainFinancials
import java.math.BigDecimal

fun main() {
    val codes = (1..2000).map { LicenseCode.generate() }
    check(codes.distinct().size == codes.size) { "Duplicate randomly issued activation code" }
    check(codes.all { LicenseCode.isValid(it) })
    check(!LicenseCode.isValid("KNK-MASTER-DEV-PASS"))
    check(!LicenseCode.isValid("KNK-ACT-ABCD-EF12"))
    check(LicenseCode.normalize("  ${codes.first().lowercase()}  ") == codes.first())
    val line = BahrainFinancials.calculateLine(BigDecimal("2"), BigDecimal("1.100"), BigDecimal("0.10"))
    check(line.net == BigDecimal("2.000") && line.vatAmount == BigDecimal("0.200") && line.gross == BigDecimal("2.200"))
    val invoice = BahrainFinancials.calculateInvoiceTotals(listOf(line))
    check(invoice.subtotal + invoice.vatTotal == invoice.total)
    println("PASS 2000 random codes, strict formatting, bypass rejection, Bahrain BHD/VAT totals")
}
