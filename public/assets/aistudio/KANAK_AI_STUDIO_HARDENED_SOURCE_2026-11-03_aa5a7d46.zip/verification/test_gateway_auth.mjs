import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const auth = fs.readFileSync(new URL('../apps-script/Auth.gs', import.meta.url),'utf8');
const rows = [
  ['user_id','email','role','active'],
  ['uid-standard','employee@example.com','standard','TRUE'],
  ['uid-disabled','disabled@example.com','admin','FALSE'],
  ['uid-admin','zanabalmuhamed@gmail.com','admin','TRUE']
];
const fakeUser = (uid,email,verified=true) => ({localId:uid,email,emailVerified:verified,providerUserInfo:[{providerId:'google.com'}]});
const tokens = {
  goodStandard: fakeUser('uid-standard','employee@example.com'),
  disabled: fakeUser('uid-disabled','disabled@example.com'),
  goodAdmin: fakeUser('uid-admin','zanabalmuhamed@gmail.com'),
  impostor: fakeUser('other-uid','employee@example.com'),
  noGoogle: {...fakeUser('uid-standard','employee@example.com'),providerUserInfo:[{providerId:'password'}]},
  unverified:fakeUser('uid-standard','employee@example.com',false),
};
const calls=[];
const context={
  PropertiesService:{getScriptProperties:()=>({getProperty:(k)=>({'KANAK_FIREBASE_API_KEY':'mock-test-project-key','KANAK_ADMIN_EMAIL':'zanabalmuhamed@gmail.com'}[k])})},
  Session:{getEffectiveUser:()=>({getEmail:()=>"zanabalmuhamed@gmail.com"})},
  UrlFetchApp:{fetch:(url,opt)=>{const body=JSON.parse(opt.payload);calls.push(body.idToken);return {
    getResponseCode:()=>tokens[body.idToken]?200:400,
    getContentText:()=>JSON.stringify({users:tokens[body.idToken]?[tokens[body.idToken]]:[]})
  }}},
  ss:{getSheetByName:(n)=>n==='Users'?{getDataRange:()=>({getValues:()=>rows})}:null}
};
vm.runInNewContext(auth,context);
function allowed(token,role='standard'){return context.authenticateAndAuthorize(context.ss,token,role)}
function reject(token,role='standard'){assert.throws(()=>allowed(token,role))}
assert.equal(allowed('goodStandard').userId,'uid-standard');
assert.equal(allowed('goodAdmin','admin').role,'admin');
reject('goodStandard','admin');
reject('disabled');
reject('impostor');
reject('noGoogle');
reject('unverified');
reject('demo_token_usr_admin_bahrain_001');
reject('');
assert.equal(calls.length,8);
console.log('PASS Firebase token lookup, exact UID/email matching, verified provider, role enforcement, disabled account, demo rejection');
