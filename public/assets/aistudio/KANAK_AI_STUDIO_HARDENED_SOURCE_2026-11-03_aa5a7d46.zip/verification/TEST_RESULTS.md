# Local verification evidence

Source checks run:

- `python verification/check_contracts.py`: PASS (no embedded deterministic license/bypass; private rules; manifest backup/cleartext policy; signed key removed; Apps Script syntax).
- `node verification/test_gateway_auth.mjs`: PASS (valid Google-linked Firebase user; UID/email exact match; verified email/provider; disabled users; unauthorized admin; demo token rejection).
- `kotlinc app/src/main/java/com/example/kanak/licensing/LicenseCode.kt app/src/main/java/com/example/kanak/domain/financial/BahrainFinancials.kt verification/KanakJvmVerification.kt -include-runtime -d /tmp/kanak-test.jar && java -jar /tmp/kanak-test.jar`: PASS (2,000 random codes, collisions in sample zero, invalid bypass rejected, BHD 3-decimal VAT reconciliation).

**NOT RUN / NOT VERIFIED:** complete Android Gradle compilation; Android UI/instrumentation; Firebase emulator rules tests; live named-Firestore deployment; live Google sign-in or two-account activation; receipt printing, invoice sync and merchant-facing functionality on a physical Android device. Tests above do not establish production acceptance.
